const roles = {
    customerRole: 'customer',
    adminRole: 'admin',
    sellerRole: 'seller'
}

module.exports = roles