const sendSMS = (phone, message) => {
    console.log(phone, message);
}

module.exports = sendSMS;